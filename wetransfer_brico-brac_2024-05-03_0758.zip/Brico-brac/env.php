<?php
$dsn = 'mysql:host=localhost;dbname=bricobrac;charset=utf8';
$db_user = 'root';
$db_password = '';