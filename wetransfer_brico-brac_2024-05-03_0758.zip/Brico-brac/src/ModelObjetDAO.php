<?php

public static function getRole($id)
{
    $req = Connexion::getInstance()->prepare("SELECT libelle
            from utilisateur
            join role on role.id = utilisateur.idRole
            where utilisateur.id = :id");
                    $req->bindValue(':id',$id,PDO::PARAM_INT);
                    $req->execute();
                    $res = $req->fetch();
                    return $res;
}

public static function insertUtilisateur($nom,$prenom,$email,$mot_de_passe,$idRole)
{
    $req = Connexion::getInstance()->prepare("INSERT INTO utilisateur (nom,prenom,email,mot_de_passe,idRole)
    VALUES (:nom,:prenom,:email,:mot_de_passe,:idRole)");
    $req->bindValue(':nom',$nom,PDO::PARAM_STR);
    $req->bindValue(':prenom',$prenom,PDO::PARAM_STR);
    $req->bindValue(':email',$email,PDO::PARAM_STR);
    $req->bindValue(':mot_de_passe',$mot_de_passe,PDO::PARAM_STR);
    $req->bindValue(':idRole',$idRole,PDO::PARAM_INT);
    $req->execute();

}

public static function insertLog($idUtilisateur,$action,$date_et_heure)
{
    $req = Connexion::getInstance()->prepare("INSERT INTO log (idUtilisateur,action,date_et_heure)
    VALUES (:idUtilisateur,:action,:date_et_heure)");
    $req->bindValue(':idUtilisateur',$idUtilisateur,PDO::PARAM_INT);
    $req->bindValue(':action',$action,PDO::PARAM_STR);
    $req->bindValue(':date_et_heure',$date_et_heure,PDO::PARAM_STR);
    $req->execute();
}

public static function getIdUtilisateur($email){
    $req = Connexion::getInstance()->prepare("SELECT id FROM utilisateur WHERE utilisateur.email =:email");
    $req->bindValue(':email',$email,PDO::PARAM_STR);
    $req->execute();
    $res = $req->fetch();
    return $res;
}
