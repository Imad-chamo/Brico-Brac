<?php
// Incluez le fichier de connexion à la base de données
include 'bdd.php';

if (isset($_POST['submit'])) {
    $article_id = $_POST['article_id'];
    $nom = $_POST['nom'];
    $prix_ht = $_POST['prix_ht'];
    $tva = $_POST['tva'];
    $pourcentage = $_POST['pourcentage'];
    $nouveaute = isset($_POST['nouveaute']) ? 1 : 0;

    // Mettez à jour les informations de l'article dans la base de données
    $query = "UPDATE article SET Nom = :nom, Prix_HT = :prix_ht, TVA = :tva, Pourcentage = :pourcentage, Nouveauté = :nouveaute WHERE ID = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $article_id, PDO::PARAM_INT);
    $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
    $stmt->bindParam(':prix_ht', $prix_ht, PDO::PARAM_STR);
    $stmt->bindParam(':tva', $tva, PDO::PARAM_INT);
    $stmt->bindParam(':pourcentage', $pourcentage, PDO::PARAM_INT);
    $stmt->bindParam(':nouveaute', $nouveaute, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: ../product_managment.php");
        exit;
    } else {
        echo 'Une erreur s\'est produite lors de la mise à jour de l\'article.';
    }
} else {
    echo 'Aucune soumission de formulaire détectée.';
}
?>
