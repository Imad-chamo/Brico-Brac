-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 30 oct. 2023 à 15:10
-- Version du serveur : 8.2.0
-- Version de PHP : 7.4.3-4ubuntu2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bricobracbis`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `Nom` varchar(255) DEFAULT NULL,
  `Référence` varchar(50) DEFAULT NULL,
  `Prix_HT` float DEFAULT NULL,
  `TVA` float DEFAULT NULL,
  `Pourcentage` float DEFAULT NULL,
  `Nouveauté` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`Nom`, `Référence`, `Prix_HT`, `TVA`, `Pourcentage`, `Nouveauté`) VALUES
('marteau de menuisier bois verni', '81968453', 8.9, 20, NULL, 0),
('marteau massette fibre de verre', '80166978', 21.9, 20, NULL, 0),
('maillet de menuisier bois', '82039106', 14.9, 20, NULL, 0),
('marteau arrache-clou', '81968500', 12.9, 20, NULL, 0),
('tournevis électricien plat', '74936295', 1.95, 20, NULL, 1),
('tournevis électricien isolé plat', '67337361', 5.1, 20, NULL, 0),
('tournevis testeur de tension plat', '76292503', 2.9, 20, NULL, 0),
('tournevis sans fil', '81900760', 40, 20, NULL, 0),
('jeu de tournevis', '73923500', 34.9, 20, NULL, 1),
('tournevis cruciforme', '74936246', 3.2, 20, NULL, 0),
('jeu de tournevis torx', '74936372', 17.9, 20, 15, 0),
('tournevis boule cruciforme', '73708264', 3.95, 20, NULL, 0),
('scie de carreleur', '18850476', 9.95, 20, NULL, 0),
('lot de 2 lames pour scie à métaux', '70709401', 2.5, 20, 10, 0),
('scie à métaux', '70907452', 8.9, 20, NULL, 0),
('scie égoïne de charpentier', '70907354', 10.9, 20, NULL, 0),
('boîte à onglet manuelle', '70709653', 9.9, 20, NULL, 1),
('scie japonaise', '67998931', 18.9, 20, NULL, 0),
('scie à bûche', '63732655', 15.6, 20, NULL, 0),
('scie universelle', '70720265', 2.05, 20, NULL, 0),
('fourreau pour scie', '70709345', 3.9, 20, NULL, 0),
('scie à chantourner de plaquiste', '73550442', 5.99, 20, NULL, 0),
('pince coupante', '69241060', 39, 20, NULL, 0),
('pince à sertir les rails', '80150490', 24.9, 20, NULL, 0),
('pince à agraphage des profiles', '80124107', 55, 20, NULL, 0),
('pince à dénuder', '80125159', 8.9, 20, NULL, 0),
('pince-clé multiprise', '69587994', 49.9, 20, NULL, 1),
('pince coupe-mosaïque', '18699366', 19.9, 20, NULL, 0),
('pince perroquet', '18699345', 14.9, 20, NULL, 0),
('pince à cosse isolée', '70059913', 25.9, 20, NULL, 0),
('pince coupe-carrelage', '18699310', 9.9, 20, NULL, 0),
('pince à cintrer', '74669791', 20.4, 20, NULL, 0),
('pince coupe-boulons coupante', '80125144', 20.9, 20, NULL, 0),
('cisaille à tôle à ardoise coupe devant', '80125135', 10.9, 20, NULL, 0),
('pince pour collier de fixation', '66502576', 17.35, 20, NULL, 0),
('pince à bec', '80125154', 10.9, 20, NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `ID` int NOT NULL,
  `Utilisateur_ID` int DEFAULT NULL,
  `Date_de_commande` date DEFAULT NULL,
  `Montant_total` float DEFAULT NULL,
  `statut` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `log`
--

CREATE TABLE `log` (
  `ID` int NOT NULL,
  `Utilisateur_ID` int DEFAULT NULL,
  `Action` varchar(255) DEFAULT NULL,
  `Date_et_heure` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `ID` int NOT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`ID`, `libelle`, `description`) VALUES
(1, 'Client', 'Peut voir et ajouter des articles a son panier'),
(2, 'Gestionnaire de commande', 'Peut ajouter/supprimer et modifier des articles et accéder au panier des utilisateurs.'),
(3, 'Administrateur', 'Peut ajouter/Supprimer et modifier les articles et les utilisateur.');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `ID` int NOT NULL,
  `Nom` varchar(255) DEFAULT NULL,
  `Prénom` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Mot_de_passe` varchar(255) DEFAULT NULL,
  `idRole` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID`, `Nom`, `Prénom`, `Email`, `Mot_de_passe`, `idRole`) VALUES
(1, 'Charles', 'Jean', 'jean.charles@gmail.com', 'bonjour1', 1),
(2, 'coltrane', 'jean', 'coltrane.jean@mediaschool.me', 'bonjour1', 2),
(3, 'pruvost', 'eric', 'eric.pruvost@business.com', 'bonjour1', 3);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Utilisateur_ID` (`Utilisateur_ID`);

--
-- Index pour la table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Utilisateur_ID` (`Utilisateur_ID`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `idRole` (`idRole`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log`
--
ALTER TABLE `log`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`Utilisateur_ID`) REFERENCES `utilisateur` (`ID`);

--
-- Contraintes pour la table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`Utilisateur_ID`) REFERENCES `utilisateur` (`ID`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`idRole`) REFERENCES `role` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
