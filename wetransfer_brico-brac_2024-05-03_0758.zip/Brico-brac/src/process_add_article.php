<?php
include 'bdd.php';

if (isset($_POST['submit'])) {
    $nom = $_POST['nom'];
    $reference = $_POST['reference'];
    $prix_ht = $_POST['prix_ht'];
    $tva = $_POST['tva'];
    $pourcentage = isset($_POST['pourcentage']) ? $_POST['pourcentage'] : null;
    $nouveaute = isset($_POST['nouveaute']) ? 1 : 0;

  // Validez que 'pourcentage' est un nombre valide ou null
  $pourcentage = isset($_POST['pourcentage']) ? floatval($_POST['pourcentage']) : null;
    
  $nouveaute = isset($_POST['nouveaute']) ? 1 : 0;

    // Préparez la requête d'insertion
    $insert_query = "INSERT INTO article (Nom, Référence, Prix_HT, TVA, Pourcentage, Nouveauté) VALUES (:nom, :reference, :prix_ht, :tva, :pourcentage, :nouveaute)";
    $stmt = $db->prepare($insert_query);

    // Liez les paramètres
    $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
    $stmt->bindParam(':reference', $reference, PDO::PARAM_STR);
    $stmt->bindParam(':prix_ht', $prix_ht, PDO::PARAM_STR);
    $stmt->bindParam(':tva', $tva, PDO::PARAM_STR);
    $stmt->bindParam(':nouveaute', $nouveaute, PDO::PARAM_INT);
    $stmt->bindParam(':pourcentage', $pourcentage, PDO::PARAM_INT); 
    // Exécutez la requête
    $stmt->execute();

    // Redirigez l'utilisateur vers la page de liste des produits après l'ajout de l'article
    header("Location: ../product_managment.php");
    exit();
}
?>
