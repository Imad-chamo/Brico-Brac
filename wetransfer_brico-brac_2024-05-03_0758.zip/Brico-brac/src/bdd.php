<?php
// require_once('C:\xampp\htdocs\dev\Brico-brac\env.php');
// Le fichier env.php doit être indiqué dans le fichier .gitignore 
// Le fichier env.php doit être créé à la racine du dossier Brico-brac et contenir les lignes suivantes (avec les valeurs à ajuster selon les paramètres locaux du PC).
$dsn = 'mysql:host=localhost;dbname=bricobrac;charset=utf8';
$db_user = 'root';
$db_password = '';

try {
    $db = new PDO($dsn, $db_user, $db_password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>