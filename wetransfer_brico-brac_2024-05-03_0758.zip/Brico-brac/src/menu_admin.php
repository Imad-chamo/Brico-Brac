<?php
// Vous devez inclure la vérification du rôle de l'utilisateur ici.
// Par exemple, supposons que le rôle de l'utilisateur est stocké dans $_SESSION['user_role'].

// Définissez le rôle de l'utilisateur. Par exemple, 3 pour le rôle 3.
$userRole = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Menu</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <!-- ... (rest of your navigation bar) ... -->
    <ul class="navbar-nav ms-auto">
        <!-- Gestion des produits -->
        <li class="nav-item" style="margin-right: 60px;">
            <a class="nav-link text-dark" href="product_managment.php">Gestion des produits</a>
        </li>
        <!-- Ajouter un article -->
        <li class="nav-item" style="margin-right: 60px;"> 
            <a class="nav-link" href="add_article.php">Ajouter un article</a>
        </li>
        <!-- Gestion des utilisateurs -->
        <?php if ($userRole === 3) { // Vérifiez le rôle de l'utilisateur ?>
            <li class="nav-item" style="margin-right: 60px"> 
                <a class="nav-link" href="users_management.php">Gestion des utilisateurs</a>
            </li>
        <?php } ?>
        <li class="nav-item" style="margin-right: 60px;">
            <a class="nav-link" href="login_client.php"><img src="src/img/2500881.png" alt="" style="width: 25px; height: 25px;"></a>
        </li>
    </ul>
</nav>
</body>
</html>
