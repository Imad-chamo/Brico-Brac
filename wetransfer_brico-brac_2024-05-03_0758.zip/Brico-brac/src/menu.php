<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Menu</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><img src="src/img/logo.png" alt="" style="width: 80px; height: auto; margin-left: 60px;"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item" style="margin-right: 60px;">
          <a class="nav-link text-dark" href="index.php">accueil</a>
        </li>
        <li class="nav-item" style="margin-right: 60px;"> 
          <a class="nav-link" href="product_list.php">produits</a>
        </li>
        <li class="nav-item" style="margin-right: 60px;">
           <a class="nav-link" href="cart.php"><img src="src/img/panier-icon.svg" alt="" style="width: 25px; height: 25px;"></a>
        </li>
        <li class="nav-item" style="margin-right: 60px;">
          <a class="nav-link" href="login_client.php"><img src="src/img/2500881.png" alt="" style="width: 25px; height: 25px;"></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>