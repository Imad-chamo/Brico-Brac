<?php
session_start(); // Démarrez la session

// Incluez votre fichier de configuration de la base de données
include 'bdd.php';

// Vérifiez si le formulaire de commande a été soumis
if (isset($_POST['valider_commande'])) {
    // Récupérez les informations de livraison depuis le formulaire
    $adresse = $_POST['adresse'];
    $code_postal = $_POST['code_postal'];
    $ville = $_POST['ville'];
    $telephone = $_POST['telephone'];
    $commentaire = $_POST['commentaire'];

    // Récupérez les informations de paiement depuis le formulaire
    $numero_carte = $_POST['numero_carte'];
    $date_expiration = $_POST['date_expiration'];
    $cryptogramme = $_POST['cryptogramme'];

    // Obtenez l'ID de l'utilisateur à partir de la session
    $utilisateur_id = $_SESSION['user_id'];

            
    // Fonction de calcul du prix TTC
    function calculateTTC($ht, $tva) {
        $ttc = $ht * (1 + ($tva / 100));
        return number_format($ttc, 2, '.', '');
    }

    // Calcul du montant total
            $total_query = "SELECT SUM(article.Prix_HT * panier.quantity) AS total
            FROM panier
            INNER JOIN article ON panier.product_id = article.ID
            WHERE panier.client_id = $utilisateur_id";

            $total_result = $db->query($total_query);

            if ($total_result && $total_result->rowCount() > 0) {
                $total_row = $total_result->fetch();
                $total_amount = calculateTTC($total_row['total'], 20); // 20 est la TVA (mettez votre valeur correcte)
            }

    try {
        // Commencez une transaction pour assurer la cohérence des données
        $db->beginTransaction();

        // Insérez les informations de livraison dans la table "commande"
        $insert_commande = "INSERT INTO commande (utilisateur_id, adresse_livraison, code_postal_livraison, ville_livraison, telephone_livraison, commentaire_livraison, Date_de_commande, Montant_total) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)";
        $stmt = $db->prepare($insert_commande);
        $stmt->execute([$utilisateur_id, $adresse, $code_postal, $ville, $telephone, $commentaire, $total_amount]);

        // Récupérez l'ID de la commande nouvellement insérée
        $commande_id = $db->lastInsertId();

        // Insérez les informations de paiement dans la table "commande"
        $insert_paiement = "UPDATE commande SET numero_carte = ?, date_expiration = ?, cryptogramme = ? WHERE id = ?";
        $stmt = $db->prepare($insert_paiement);
        $stmt->execute([$numero_carte, $date_expiration, $cryptogramme, $commande_id]);

        // Récupérez le contenu du panier de l'utilisateur depuis la table "panier"
        $select_panier = "SELECT product_id, quantity FROM panier WHERE client_id = ?";
        $stmt = $db->prepare($select_panier);
        $stmt->execute([$utilisateur_id]);

        while ($row = $stmt->fetch()) {
            $article_id = $row['product_id'];
            $quantite = $row['quantity'];

            $insert_contenu_commande = "INSERT INTO contenu_commande (commande_id, article_id, quantite) VALUES (?, ?, ?)";
            $stmt_contenu = $db->prepare($insert_contenu_commande);
            $stmt_contenu->execute([$commande_id, $article_id, $quantite]);
        }

        // Supprimez les articles du panier dans la table "panier" (à faire selon votre logique)

        /// Validez la transaction
        $db->commit();

        // Supprimez les articles du panier de l'utilisateur une fois la commande passée
        $delete_panier = "DELETE FROM panier WHERE client_id = ?";
        $stmt_delete = $db->prepare($delete_panier);
        $stmt_delete->execute([$utilisateur_id]);

        // Réinitialisez le panier (c'est-à-dire, supprimez les articles du panier) dans la table "panier", selon votre logique

        // Redirigez l'utilisateur vers une page de confirmation de commande
        header('Location: ../order_ok.php');
        exit;
    } catch (PDOException $e) {
        // En cas d'erreur, annulez la transaction
        $db->rollBack();
        echo "Une erreur s'est produite : " . $e->getMessage();
    }
} else {
    // Le formulaire n'a pas été soumis, redirigez l'utilisateur vers la page de commande
    header('Location: ../order.php');
    exit;
}
