<?php
 
 // Incluez le fichier de connexion à la base de données
include 'bdd.php';

if (isset($_POST['submit']))
{
    $utilisateur_id = $_POST['utilisateur_id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];
    $id_role = $_POST['id_role'];

    // Requete qui permet de modifier les valeurs de l'utilisateur dans le sgbd
    $query = "UPDATE utilisateur SET Nom = :nom, Prénom = :prenom, Email = :email, Mot_de_passe = :mot_de_passe, idRole = :id_role WHERE ID = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $utilisateur_id, PDO::PARAM_INT); // Utilisez PDO::PARAM_INT pour un ID.
    $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
    $stmt->bindParam(':prenom', $prenom, PDO::PARAM_STR); // Supprimez l'espace avant "prenom".
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':mot_de_passe', $mot_de_passe, PDO::PARAM_STR);
    $stmt->bindParam(':id_role', $id_role, PDO::PARAM_INT);
    
    // Assurez-vous que les noms de colonnes et les paramètres de liaison correspondent exactement à votre base de données.
    


    if ($stmt->execute()) {
        header("Location: ../users_management.php");
        exit;
    } else {
        echo 'Une erreur s\'est produite lors de la mise à jour de l\'utilisateur.';
    }
} else {
    echo 'Aucune soumission de formulaire détectée.';
}


?>