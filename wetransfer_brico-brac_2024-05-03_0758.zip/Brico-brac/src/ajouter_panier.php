<?php
session_start(); // Démarrez la session

// Incluez votre fichier de configuration de la base de données
include 'bdd.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reference']) && isset($_POST['quantite'])) {
        $reference = $_POST['reference'];
        $quantite = intval($_POST['quantite']); // Assurez-vous que la quantité est un entier

        // Vérifiez que la quantité est valide (par exemple, supérieure à 0)

        // Récupérez l'ID du client à partir de la session (adapté à votre structure de données)
        $client_id = $_SESSION['user_id']; // Assurez-vous que la clé de session est correcte

        // Récupérez l'ID du produit à partir de la table des articles en utilisant la référence
        $query = "SELECT ID FROM article WHERE Référence = '$reference'";
        $result = $db->query($query);
        $row = $result->fetch();

        if ($row) {
            $product_id = $row['ID'];

            // Insérez l'article dans la table du panier
            $insert_query = "INSERT INTO panier (client_id, product_id, quantity) VALUES ($client_id, $product_id, $quantite)";
            $db->query($insert_query);

            // Redirigez l'utilisateur vers la page de liste des produits ou ailleurs
            header('Location: ../cart.php'); // Remplacez 'liste_produits.php' par la page souhaitée
            exit();
        }
    } 
}
