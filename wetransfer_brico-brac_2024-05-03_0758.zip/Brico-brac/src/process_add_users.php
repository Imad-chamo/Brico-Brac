<?php
include 'bdd.php';
session_start(); 

if (isset($_POST['submit'])) {
    if (!empty($_POST)) {
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $mot_de_passe = $_POST['mot_de_passe'];
        $id_role = $_POST['id_role']; 

        // Validez que $id_role est 1, 2 ou 3
        if ($id_role == 1 || $id_role == 2 || $id_role == 3) {
            $insert_query = "INSERT INTO utilisateur (Nom, Prénom, Email, Mot_de_passe, idRole) VALUES (:nom, :prenom, :email, :mot_de_passe, :id_role)";
            $stmt = $db->prepare($insert_query);

            // Liez les paramètres
            $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
            $stmt->bindParam(':prenom', $prenom, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':mot_de_passe', $mot_de_passe, PDO::PARAM_STR);
            $stmt->bindParam(':id_role', $id_role, PDO::PARAM_INT);

            // Exécutez la requête
            $stmt->execute();

            // date_default_timezone_set('Europe/Paris');
            // $idUtilisateur = ModeleObjetDAO::getIdUtilisateur($_SESSION['email'])['id'];
            // $action = "Ajout d'un utilisateur par ".$_SESSION['nom'];
            // $date_et_heure = date("Y-m-d H:i:s");
            // ModeleObjetDAO::insertLog($idUtilisateur, $action, $date_et_heure);

            header("Location: ../users_management.php"); // Corrigez la redirection vers "users_management.php".
            exit();
        } else {
            // Le rôle n'est pas valide, vous pouvez gérer l'erreur ici, par exemple en affichant un message.
            echo "Le rôle sélectionné n'est pas valide.";
        }
    }
}
?>
